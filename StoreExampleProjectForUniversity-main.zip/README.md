## Store Project For University

<html lang="en">
<body>
<div>
    1. <code onclick="navigator.clipboard.writeText('php artisan migrate')">php artisan migrate</code>
    <br>
    <br>
    2. The <code style="cursor:pointer;"><a href="#">Postman Collection Json File</a></code> will soon be updated here.
    <br><br>
    3. After downloading the postman specify the <code>base_url</code> in the environment variables defined in it, to start testing the endpoints.
</div>
</body>
</html>
